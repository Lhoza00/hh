<?php 
    declare(strict_types=1);
    session_start();
    require_once __DIR__ . '/../config/config.php';
    require_once __DIR__ . '/../config/database.php';
    require_once __DIR__ . '/../routes/index.php';

    